import { NextResponse } from "next/server";
import { getRedis } from "@/lib/redis";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const COUNTER_KEY = "normal-link-click-count";

export async function GET() {
  try {
    const redis = getRedis();
    const count = (await redis.get<number>(COUNTER_KEY)) ?? 0;
    return NextResponse.json({ count });
  } catch (error) {
    console.error("Could not read click counter:", error);
    return NextResponse.json(
      { error: "The counter is not configured yet. Set up the Redis environment variables." },
      { status: 503 }
    );
  }
}

export async function POST() {
  try {
    const redis = getRedis();
    const count = await redis.incr(COUNTER_KEY);
    return NextResponse.json({ count });
  } catch (error) {
    console.error("Could not increment click counter:", error);
    return NextResponse.json(
      { error: "The counter is temporarily unavailable." },
      { status: 503 }
    );
  }
}
