"use client";

import { useEffect, useState } from "react";

const LINK_URL =
  "https://www.youtube.com/watch?v=dQw4w9WgXcQ&xstg=CAMSEBUJ_b-oH-PhF0yjBgb_zzE%3D";

type CounterResponse = { count?: number; error?: string };

export default function Home() {
  const [count, setCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [clicking, setClicking] = useState(false);

  useEffect(() => {
    let cancelled = false;

    fetch("/api/counter", { cache: "no-store" })
      .then(async (response) => {
        const data = (await response.json()) as CounterResponse;
        if (!response.ok) throw new Error(data.error || "Could not load the counter.");
        if (!cancelled) setCount(data.count ?? 0);
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Could not load the counter.");
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  async function handleLinkClick(event: React.MouseEvent<HTMLAnchorElement>) {
    event.preventDefault();
    if (clicking) return;

    // Open the destination immediately so the browser does not block the new tab.
    window.open(LINK_URL, "_blank", "noopener,noreferrer");
    setClicking(true);
    setError(null);

    try {
      const response = await fetch("/api/counter", {
        method: "POST",
        cache: "no-store",
      });
      const data = (await response.json()) as CounterResponse;
      if (!response.ok) throw new Error(data.error || "Could not update the counter.");
      setCount(data.count ?? 0);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update the counter.");
    } finally {
      setClicking(false);
    }
  }

  return (
    <main className="page-shell">
      <section className="content" aria-labelledby="page-title">
        <p className="eyebrow">A completely ordinary webpage</p>
        <h1 id="page-title">This is definitely a normal link...</h1>

        <a className="normal-link" href={LINK_URL} onClick={handleLinkClick}>
          {LINK_URL}
        </a>

        <div className="counter" aria-live="polite" aria-atomic="true">
          <span className="counter-number">{count === null ? "—" : count.toLocaleString()}</span>
          <span className="counter-label">{count === 1 ? "click" : "clicks"}</span>
        </div>
        {error && <p className="error-message">{error}</p>}
        <p className="footnote">The number goes up whenever someone clicks the link.</p>
      </section>
    </main>
  );
}
