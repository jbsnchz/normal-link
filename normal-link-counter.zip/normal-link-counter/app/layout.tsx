import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "A Definitely Normal Link",
  description: "This is definitely a normal link...",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
