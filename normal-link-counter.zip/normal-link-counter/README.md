# A Definitely Normal Link

A small Next.js app intended for Vercel. It displays the requested heading, a YouTube link, and a shared click counter stored in Upstash Redis.

## Requirements

- Node.js 20 or newer
- A GitHub account (for Git-based deployment)
- A free Upstash Redis database or the Vercel Upstash integration

## Run locally

```bash
npm install
```

Create `.env.local` in the project root with your Redis credentials:

```env
UPSTASH_REDIS_REST_URL=https://your-database.upstash.io
UPSTASH_REDIS_REST_TOKEN=your-secret-token
```

Alternatively, if using the Vercel/Upstash integration, the app also accepts `KV_REST_API_URL` and `KV_REST_API_TOKEN`.

Then run:

```bash
npm run dev
```

Open http://localhost:3000.

## Deploy to Vercel through GitHub

1. Create a GitHub repository and push this folder's files to it.
2. In Vercel, select **Add New → Project**, import the repository, and deploy it as a Next.js project.
3. Create/connect an Upstash Redis database using the Upstash integration in the Vercel dashboard, or create one at https://console.upstash.com/.
4. In Vercel Project Settings → Environment Variables, add either:
   - `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`, or
   - `KV_REST_API_URL` and `KV_REST_API_TOKEN`.
5. Redeploy after adding the environment variables.

The counter is global across visitors and persists in Redis. The counter starts at zero for a new Redis database and is not incremented by simply visiting the page.
